
import tensorflow as tf
from keras.models import load_model
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
from yahoo_fin.stock_info import get_data
from sklearn.preprocessing import MinMaxScaler
import plotly.graph_objs as go
from plotly.subplots import make_subplots
# load model
model = load_model('lstm_model.h5')
def getting_data(symbol):
    df=get_data(symbol,start_date='2023-01-01')
    data = df.filter(['close'])
    return data

data=getting_data('amzn')

scaler = MinMaxScaler(feature_range=(0,1))

def scaling_data(data):
    dataset = data.values
    scaled_data = scaler.fit_transform(dataset)
    return scaled_data
scaled_data=scaling_data(data)

def predicting(scaled_data):
    dataset = data.values
    test_data = scaled_data[:]
    x_test = []
    y_test = dataset[60:,:]
    for i in range(60, len(test_data)):
        x_test.append(test_data[i-60:i, 0])
    x_test = np.array(x_test)
    x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1 ))
    predictions = model.predict(x_test)
    predictions = scaler.inverse_transform(predictions)
    rmse = np.sqrt(np.mean(((predictions - y_test) ** 2)))
    return predictions,y_test

predictions=predicting(scaled_data)[0]
print(predictions.shape)
y_test=predicting(scaled_data)[1]

def predicted_graph(predictions):
    valid = data[60:]
    valid['Predictions'] = predictions
    trace2 = go.Scatter(x=valid.index, y=valid['close'], mode='lines', name='Val')
    trace3 = go.Scatter(x=valid.index, y=valid['Predictions'], mode='lines', name='Predictions')
    
    fig = make_subplots(rows=1, cols=1)
    
    fig.add_trace(trace2)
    fig.add_trace(trace3)
    
    fig.update_layout(title='Model',
                      xaxis_title='Date',
                      yaxis_title='Close Price USD ($)',
                      legend=dict(x=0, y=1),
                      showlegend=True)
    return fig


