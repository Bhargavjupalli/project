<?php
// Start session to retrieve user information
session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect user back to login page if not logged in
    header("Location: login.php");
    exit();
}

// Display employee page content
echo "<h2>Welcome, " . $_SESSION['username'] . "</h2>";
// Add more content as needed...

// Provide option to logout
echo "<a href='logout.php'>Logout</a>";
?>
