import pandas as pd
import numpy as np
from pandas_datareader.data import DataReader
import yfinance as yf
from pandas_datareader import data as pdr
import matplotlib.pyplot as plt
import tensorflow as tf
from keras.models import load_model
from datetime import datetime
from sklearn.preprocessing import MinMaxScaler
# load model
savedModel=load_model("lstm_model.h5")
def get_the_data():
    df = pdr.get_data_yahoo("amzn", start='2023-01-01', end=datetime.now())
    return df

def predictt(df):
    data = df.filter(['Close'])
    dataset = data.values

    scaler = MinMaxScaler(feature_range=(0,1))
    scaled_data = scaler.fit_transform(dataset)


    test_data = scaled_data[:]
    x_test = []
    y_test = dataset[60:,:]
    for i in range(60, len(test_data)):
        x_test.append(test_data[i-60:i, 0])
        
    x_test = np.array(x_test)
    x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1 ))
    x_test.shape,y_test.shape

    predictions = savedModel.predict(x_test)
    predictions = scaler.inverse_transform(predictions)

    rmse = np.sqrt(np.mean(((predictions - y_test) ** 2)))

    return predictions

import mpld3
def predicted_graph_to_html(df, predictions):
    dd = df.index[60:]
    data = df.filter(['Close'])
    dataset = data.values
    y_test = dataset[60:,:]
    
    # Plot real values and predicted values
    plt.figure(figsize=(16, 8))
    plt.plot(dd, y_test, label='Real Values')
    plt.plot(dd, predictions, label='Predicted Values', linestyle='--')
    plt.xlabel('Date')
    plt.ylabel('Close Price')
    plt.title('Real vs Predicted Values')
    plt.legend()
    
    # Convert the plot to HTML
    html_str = mpld3.fig_to_html(plt.gcf())
    plt.close()  # Close the matplotlib figure to prevent displaying it in Jupyter Notebook
    
    return html_str
